#include "stm32f103xb.h"

volatile uint16_t adc_values[2];

void CONFIG_CLOCKS(void);
void CONFIG_GPIO(void);
void CONFIG_DMA(void);
void CONFIG_ADC(void);
void CONFIG_TIM2_PWM(void);

int main(void)
{
    CONFIG_CLOCKS();
    CONFIG_GPIO();
    CONFIG_TIM2_PWM();
    CONFIG_DMA();
    CONFIG_ADC();

    while (1)
    {
        TIM2->CCR2 = adc_values[0];
        TIM2->CCR3 = adc_values[1];

        if (!(GPIOA->IDR & (1 << 4)))
        {
            TIM2->CCR4 = 4095;
        }
        else
        {
            TIM2->CCR4 = 0;
        }
    }
}

void CONFIG_CLOCKS(void)
{
    RCC->APB2ENR |= (1<<2) | (1<<9);
    RCC->APB1ENR |= (1<<0);
    RCC->AHBENR |= (1<<0);
    RCC->CFGR |= (2 << 14);
}

void CONFIG_GPIO(void)
{
    GPIOA->CRL = 0;

    GPIOA->CRL |=
            (0xA << 4)  |
            (0xA << 8)  |
            (0xA << 12);

    GPIOA->CRL |= (0x8 << 16);
    GPIOA->ODR |= (1 << 4);
}

void CONFIG_DMA(void)
{
    DMA1_Channel1->CCR &= ~(1<<0);

    DMA1_Channel1->CPAR = (uint32_t)&ADC1->DR;
    DMA1_Channel1->CMAR = (uint32_t)adc_values;

    DMA1_Channel1->CNDTR = 2;

    DMA1_Channel1->CCR =
            (1<<7) |
            (1<<5) |
            (1<<10)|
            (1<<8);

    DMA1_Channel1->CCR |= (1<<0);
}

void CONFIG_ADC(void)
{
    ADC1->CR2 |= (1<<0);

    for(volatile int i=0;i<1000;i++);

    ADC1->CR2 |= (1<<2);
    while(ADC1->CR2 & (1<<2));

    ADC1->CR1 |= (1<<8);

    ADC1->CR2 |=
            (1<<1)  |
            (1<<8)  |
            (1<<20) |
            (7<<17);

    ADC1->SQR1 = (1<<20);

    ADC1->SQR3 =
            (5<<0)  |
            (6<<5);

    ADC1->SMPR2 =
            (7<<15) |
            (7<<18);

    ADC1->CR2 |= (1<<22);
}

void CONFIG_TIM2_PWM(void)
{
    TIM2->PSC = 0;
    TIM2->ARR = 4095;

    TIM2->CCMR1 |= (6<<12) | (1<<11);
    TIM2->CCMR2 |= (6<<4) | (1<<3);
    TIM2->CCMR2 |= (6<<12) | (1<<11);

    TIM2->CCER |=
            (1<<4) |
            (1<<8) |
            (1<<12);

    TIM2->EGR |= (1<<0);
    TIM2->CR1 |= (1<<7);
    TIM2->CR1 |= (1<<0);
}
