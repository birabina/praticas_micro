#include "stm32f1xx.h"

#define FREQ_CPU        8000000UL
#define PWM_PERIODO     1000U
#define FADE_PASSO      5U
#define NUM_CORES       7U

#define ATUALIZAR_PWM(duty) \
    TIM3->CCR3 = tabela_cores[indice_cor][0] ? (PWM_PERIODO - (duty)) : PWM_PERIODO; \
    TIM3->CCR2 = tabela_cores[indice_cor][1] ? (PWM_PERIODO - (duty)) : PWM_PERIODO; \
    TIM3->CCR1 = tabela_cores[indice_cor][2] ? (PWM_PERIODO - (duty)) : PWM_PERIODO

typedef enum { ACENDENDO, APAGANDO } EstadoFade;

volatile uint8_t    indice_cor  = 0;
volatile uint32_t   duty_atual  = 0;
volatile EstadoFade estado_fade = ACENDENDO;

const uint8_t tabela_cores[NUM_CORES][3] = {
    {1, 0, 0},
    {0, 1, 0},
    {0, 0, 1},
    {1, 1, 0},
    {0, 1, 1},
    {1, 0, 1},
    {1, 1, 1}
};

void TIM2_IRQHandler(void) {
    if (TIM2->SR & TIM_SR_UIF) {
        TIM2->SR &= ~TIM_SR_UIF;

        if (estado_fade == ACENDENDO) {
            duty_atual += FADE_PASSO;
            if (duty_atual >= PWM_PERIODO) {
                duty_atual  = PWM_PERIODO;
                estado_fade = APAGANDO;
            }
        } else {
            if (duty_atual <= FADE_PASSO) {
                duty_atual  = 0;
                estado_fade = ACENDENDO;
                indice_cor  = (indice_cor + 1U) % NUM_CORES;
            } else {
                duty_atual -= FADE_PASSO;
            }
        }

        ATUALIZAR_PWM(duty_atual);
    }
}

void GPIO_TIMER_INIT(void) {
    RCC->APB2ENR |= RCC_APB2ENR_IOPAEN | RCC_APB2ENR_IOPBEN | RCC_APB2ENR_AFIOEN;
    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN | RCC_APB1ENR_TIM3EN;

    GPIOA->CRL &= ~(GPIO_CRL_MODE6 | GPIO_CRL_CNF6 | GPIO_CRL_MODE7 | GPIO_CRL_CNF7);
    GPIOA->CRL |=  (GPIO_CRL_MODE6_1 | GPIO_CRL_CNF6_1 |
                    GPIO_CRL_MODE7_1 | GPIO_CRL_CNF7_1);

    GPIOB->CRL &= ~(GPIO_CRL_MODE0 | GPIO_CRL_CNF0);
    GPIOB->CRL |=  (GPIO_CRL_MODE0_1 | GPIO_CRL_CNF0_1);

    TIM3->PSC    = 7;
    TIM3->ARR    = PWM_PERIODO - 1U;

    TIM3->CCMR1 |= TIM_CCMR1_OC1M_1 | TIM_CCMR1_OC1M_2
                 | TIM_CCMR1_OC2M_1 | TIM_CCMR1_OC2M_2;
    TIM3->CCMR2 |= TIM_CCMR2_OC3M_1 | TIM_CCMR2_OC3M_2;

    TIM3->CCER  |= TIM_CCER_CC1E | TIM_CCER_CC2E | TIM_CCER_CC3E;

    TIM3->CCR1   = PWM_PERIODO;
    TIM3->CCR2   = PWM_PERIODO;
    TIM3->CCR3   = PWM_PERIODO;

    TIM3->CR1   |= TIM_CR1_CEN;

    TIM2->PSC    = 7999;
    TIM2->ARR    = 9;
    TIM2->DIER  |= TIM_DIER_UIE;
    NVIC_EnableIRQ(TIM2_IRQn);
    TIM2->CR1   |= TIM_CR1_CEN;
}

int main(void) {
    GPIO_TIMER_INIT();

    while (1) {
        __WFI();
    }
}
